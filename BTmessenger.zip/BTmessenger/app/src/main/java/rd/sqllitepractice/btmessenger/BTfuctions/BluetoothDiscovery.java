package rd.sqllitepractice.btmessenger.BTfuctions;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;

import java.util.Set;

public class BluetoothDiscovery implements Runnable {


    private static final String TAG = "BluetoothDiscovery";

    public BluetoothAdapter mBluetoothAdapter;

    public BluetoothDiscovery(BluetoothAdapter adapter) {
        mBluetoothAdapter = adapter;
    }


    @Override
    public void run() {

        Set<BluetoothDevice> pairedDevices = mBluetoothAdapter.getBondedDevices();

        if (pairedDevices.size() > 0) {
            // There are paired devices. Get the name and address of each paired device.
            for (BluetoothDevice device : pairedDevices) {
                String deviceName = device.getName(); //Bluetooth device name
                String deviceHardwareAddress = device.getAddress(); // MAC address
            }
        }


    }
}

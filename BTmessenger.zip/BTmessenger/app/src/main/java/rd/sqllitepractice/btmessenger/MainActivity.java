package rd.sqllitepractice.btmessenger;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import rd.sqllitepractice.btmessenger.BTfuctions.BluetoothDiscovery;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private static final int REQUEST_ENABLE_BT = 1;

    //vars
    BluetoothAdapter mAdapter;

    //widgets
    Button btnSearch;
    ImageView ivClose;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnSearch = (Button)findViewById(R.id.search_BT_btn);
        ivClose = (ImageView)findViewById(R.id.close);

        //enabling bluetooth
        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (initializeBT())
                {
                    BluetoothDiscovery discovery = new BluetoothDiscovery(mAdapter);
                    Thread thread = new Thread(discovery);
                    thread.start();
                }
            }
        });

        //closing application

        ivClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();

            }
        });


    }



    private boolean initializeBT()
    {

        mAdapter = BluetoothAdapter.getDefaultAdapter();
        if(mAdapter == null)
        {
            Log.d(TAG, "init: Device doesn't support bluetooth");
            Toast.makeText(getApplicationContext(), "This device doesn't support bluetooth",Toast.LENGTH_SHORT).show();
            return false;
        }
        else if (!mAdapter.isEnabled())
        {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
            return true;
        }

        Log.d(TAG, "initializeBT: Bluetooth is already enabled.");
        return true;

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode==RESULT_OK)
        {
            Toast.makeText(getApplicationContext(), "Bluetooth enabled", Toast.LENGTH_SHORT).show();
        }
        else if (resultCode == RESULT_CANCELED)
        {
            Toast.makeText(getApplicationContext(), "Error occurred while enabling bluetooth", Toast.LENGTH_SHORT).show();
        }
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}
